# Bildirim Tanı 2.0

Android uygulaması; kendi alarm testlerine ek olarak kullanıcının seçtiği yüklü uygulamanın bildirim gösterilme/kaldırılma olaylarını gözlemlemeye yardımcı olur.

## Özellikler
- Telefonda başlatılabilen uygulamaları listeler; bir hedef uygulama seçilir.
- Android'in **Bildirim Erişimi** ayarıyla kullanıcı açıkça izin verirse seçilen paketin yeni bildirimleri ve kaldırılma olayları yerel kayda alınır.
- Başlık/metin aynıysa ve 2 dakika içinde tekrar gösterildiyse "olası tekrar" işareti ekler. Bu sezgisel bir uyarıdır; tek başına hata kanıtı değildir.
- Bildirim ID'si, etiketi, grubu, başlığı, metni, gösterilme/kaldırılma zamanı ve Android'in bildirim kaldırma nedeni kaydedilir.
- Olay raporu ekranda gösterilebilir, kopyalanabilir ve kullanıcı tarafından paylaşılabilir.
- Mevcut alarm testi ve cihaz ayarı raporu korunmuştur.

## GitHub üzerinden APK oluşturma
1. ZIP'i çıkarıp içindeki `BildirimTani` klasörünün içeriğini bir GitHub deposunun kök dizinine yükleyin.
2. `main` (veya `master`) dalına gönderin.
3. **Actions → Build APK** iş akışının tamamlanmasını bekleyin.
4. Tamamlanan iş akışının **Artifacts** bölümünden `BildirimTani-APK` dosyasını indirin. ZIP içindeki `app-debug.apk` dosyasını telefona kurun.

İş akışı ayrıca **Actions → Build APK → Run workflow** ile elle çalıştırılabilir.

## Telefonda test
1. Bildirim Tanı'yı açıp **Yüklü uygulamaları listele** düğmesine dokunun.
2. Listeden Ezan Vakti uygulamasını seçin ve **Seçili uygulamayı izlemeye al** düğmesine dokunun.
3. **Bildirim erişimi ayarlarını aç** düğmesine dokunup Android ayarlarında Bildirim Tanı'ya izin verin. Bu, Android'in hassas bir erişimidir; yalnızca güveniyorsanız açın.
4. Bildirim Tanı'ya geri dönün. Ezan Vakti uygulamasının bir sonraki bildirim olayları kaydedilir.
5. Vakit bildirimini bekleyin. Bildirimi temizleme veya uygulamayı açma adımlarını uygulayın; ardından **Bildirim olaylarını göster** ile zaman damgalarını karşılaştırın.
6. **Tanı raporunu kopyala/paylaş** ile sonucu dışa aktarabilirsiniz. Rapor, bildirim başlığı/metni içerebileceğinden paylaşmadan önce gözden geçirin.

## Sınırlar
- Android, başka uygulamanın iç alarm planını, kaynak kodunu veya neden bildirim oluşturduğunu doğrudan açıklamaz. Bu araç gözlenen bildirim olaylarını kaydeder; uygulama içindeki kesin kök nedeni garanti etmez.
- Gecikme hesabı için hedef uygulamanın planlanan alarm zamanı ayrıca bilinmelidir. Bu sürüm, hedef uygulamanın gerçek bildirim gösterilme zamanını kaydeder; vakit hesabının planlanan zamanını otomatik bilemez.
- Bildirim izleme izni verilene kadar olaylar kaydedilmez; izin verildikten sonra da ilk etapta yalnızca yeni olaylar izlenir.
- Aynı başlık/metin farklı ve meşru bildirimlerde de kullanılabilir. "Olası tekrar" yalnızca yardımcı bir sinyaldir.
- Kullanım erişimi düğmesi isteğe bağlı Android ayarlarını açar; bu sürüm uygulama açılışlarını otomatik olarak olay günlüğüne yazmaz.
- Olaylar cihazda yerel olarak saklanır (son 300 olay). Uygulama verileri temizlenirse kayıtlar silinir.
- Android üretici arayüzleri ve sürümler arasında ayar ekranları farklı olabilir.

## Teknik
- Kotlin, Android SDK 35, minSdk 26, targetSdk 35.
- APK, GitHub Actions tarafından `assembleDebug` ile derlenir.
