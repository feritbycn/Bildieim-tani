package com.example.bildirimtani

import android.app.AppOpsManager
import android.content.ComponentName
import android.content.Context
import android.provider.Settings
import org.json.JSONObject
import java.io.File

/** İzlenen uygulamanın bildirim olaylarını telefonda yerel dosyada tutar. Hiçbir yere gönderilmez. */
object NotifStore {
    private const val FILE = "events.jsonl"
    private const val MAX_LINES = 800
    private val lock = Any()

    fun prefs(c: Context) = c.getSharedPreferences("monitor", Context.MODE_PRIVATE)
    fun targetPkg(c: Context): String? = prefs(c).getString("pkg", null)
    fun targetLabel(c: Context): String? = prefs(c).getString("label", null)

    private fun file(c: Context) = File(c.filesDir, FILE)

    fun append(c: Context, o: JSONObject) {
        synchronized(lock) {
            try {
                val f = file(c)
                f.appendText(o.toString() + "\n")
                if (f.length() > 400_000L) {
                    val lines = f.readLines()
                    f.writeText(lines.takeLast(MAX_LINES).joinToString("\n") + "\n")
                }
            } catch (_: Throwable) {}
        }
    }

    fun readAll(c: Context): List<JSONObject> = synchronized(lock) {
        try {
            val f = file(c)
            if (!f.exists()) emptyList()
            else f.readLines().mapNotNull { l ->
                try { if (l.isBlank()) null else JSONObject(l) } catch (_: Throwable) { null }
            }
        } catch (_: Throwable) { emptyList() }
    }

    fun clear(c: Context) { synchronized(lock) { try { file(c).delete() } catch (_: Throwable) {} } }

    fun listenerEnabled(c: Context): Boolean {
        val s = Settings.Secure.getString(c.contentResolver, "enabled_notification_listeners") ?: return false
        return s.split(":").any { ComponentName.unflattenFromString(it)?.packageName == c.packageName }
    }

    fun opMode(c: Context, op: String, uid: Int, pkg: String): Int {
        val ao = c.getSystemService(AppOpsManager::class.java)
        if (android.os.Build.VERSION.SDK_INT >= 29) return ao.unsafeCheckOpNoThrow(op, uid, pkg)
        @Suppress("DEPRECATION")
        val m = ao.checkOpNoThrow(op, uid, pkg)
        return m
    }

    fun usageAllowed(c: Context): Boolean = try {
        opMode(c, "android:get_usage_stats", android.os.Process.myUid(), c.packageName) == AppOpsManager.MODE_ALLOWED
    } catch (_: Throwable) { false }
}
