package com.example.bildirimtani

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.os.Build
import android.content.Context
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NotificationMonitor : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        record(sbn, "GÖSTERİLDİ", null)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification, rankingMap: RankingMap, reason: Int) {
        val why = when (reason) {
            REASON_CLICK -> "Bildirime dokunuldu"
            REASON_CANCEL -> "Uygulama/sistem iptal etti"
            REASON_CANCEL_ALL -> "Tüm bildirimler temizlendi"
            REASON_ERROR -> "Bildirim hatası"
            REASON_PACKAGE_CHANGED -> "Paket değişti"
            REASON_PACKAGE_BANNED -> "Uygulama bildirimleri engellendi"
            REASON_APP_CANCEL -> "Kaynak uygulama kaldırdı"
            REASON_APP_CANCEL_ALL -> "Kaynak uygulama tümünü kaldırdı"
            REASON_TIMEOUT -> "Zaman aşımı"
            REASON_CHANNEL_BANNED -> "Bildirim kanalı engellendi"
            REASON_SNOOZED -> "Ertelendi"
            REASON_GROUP_SUMMARY_CANCELED -> "Grup özeti kaldırıldı"
            else -> "Diğer neden ($reason)"
        }
        record(sbn, "KALDIRILDI", why)
    }

    private fun record(sbn: StatusBarNotification, event: String, reason: String?) {
        val sp = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val selected = sp.getString(KEY_PACKAGE, null) ?: return
        if (sbn.packageName != selected || sbn.packageName == packageName) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty().take(180)
        val body = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty().take(300)
        val now = System.currentTimeMillis()
        val signature = "$selected|$title|$body"
        val previousSig = sp.getString("last_sig", "")
        val previousAt = sp.getLong("last_sig_at", 0L)
        val duplicate = event == "GÖSTERİLDİ" && signature == previousSig && now - previousAt <= 120_000L
        if (event == "GÖSTERİLDİ") sp.edit().putString("last_sig", signature).putLong("last_sig_at", now).apply()
        val entry = JSONObject().apply {
            put("at", now); put("event", event); put("package", selected)
            put("app", try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(selected, 0)).toString() } catch (_: Exception) { selected })
            put("title", title); put("body", body); put("id", sbn.id); put("tag", sbn.tag ?: "")
            put("key", sbn.key); put("when", sbn.notification.`when`); put("group", sbn.notification.group ?: "")
            put("duplicateSuspected", duplicate); put("reason", reason ?: "")
        }
        synchronized(LOCK) {
            val old = sp.getString(KEY_EVENTS, "") ?: ""
            val lines = (listOf(entry.toString()) + old.lines().filter { it.isNotBlank() }).take(MAX_EVENTS)
            sp.edit().putString(KEY_EVENTS, lines.joinToString("\n")).apply()
        }
    }

    companion object {
        const val PREFS = "log"
        const val KEY_PACKAGE = "monitor_package"
        const val KEY_EVENTS = "notification_events"
        const val MAX_EVENTS = 300
        val LOCK = Any()
        fun formatTime(t: Long): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault()).format(Date(t))
    }
}
