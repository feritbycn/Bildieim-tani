package com.example.bildirimtani

import android.app.Notification
import android.app.NotificationChannel
import android.content.ComponentName
import android.os.Build
import android.os.Process
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONObject

/** Seçilen tek uygulamanın bildirim geliş/silinme olaylarını zaman damgasıyla kaydeder. */
class NotifWatcher : NotificationListenerService() {
    companion object {
        @Volatile var instance: NotifWatcher? = null
    }

    override fun onListenerConnected() {
        instance = this
        sys("Dinleyici bağlandı")
    }

    override fun onListenerDisconnected() {
        instance = null
        sys("Dinleyici bağlantısı koptu (sistem durdurdu)")
        try {
            if (Build.VERSION.SDK_INT >= 24) requestRebind(ComponentName(this, NotifWatcher::class.java))
        } catch (_: Throwable) {}
    }

    private fun sys(msg: String) {
        NotifStore.append(this, JSONObject().put("t", "S").put("rx", System.currentTimeMillis()).put("msg", msg))
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            val pkg = NotifStore.targetPkg(this) ?: return
            if (sbn.packageName != pkg) return
            val n = sbn.notification
            val ex = n.extras
            val title = ex?.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val text = (ex?.getCharSequence(Notification.EXTRA_TEXT)
                ?: ex?.getCharSequence(Notification.EXTRA_BIG_TEXT))?.toString() ?: ""
            NotifStore.append(this, JSONObject()
                .put("t", "P").put("pkg", pkg)
                .put("rx", System.currentTimeMillis())
                .put("post", sbn.postTime).put("when", n.`when`)
                .put("key", sbn.key).put("id", sbn.id).put("tag", sbn.tag ?: "")
                .put("ch", n.channelId ?: "").put("flags", n.flags)
                .put("title", title.take(80)).put("text", text.take(120)))
        } catch (_: Throwable) {}
    }

    override fun onNotificationRemoved(
        sbn: StatusBarNotification, rankingMap: NotificationListenerService.RankingMap, reason: Int
    ) {
        try {
            val pkg = NotifStore.targetPkg(this) ?: return
            if (sbn.packageName != pkg) return
            NotifStore.append(this, JSONObject()
                .put("t", "R").put("pkg", pkg)
                .put("rx", System.currentTimeMillis())
                .put("key", sbn.key).put("id", sbn.id).put("tag", sbn.tag ?: "")
                .put("ch", sbn.notification?.channelId ?: "")
                .put("reason", reason))
        } catch (_: Throwable) {}
    }

    fun channelsOf(pkg: String): List<NotificationChannel> = try {
        getNotificationChannels(pkg, Process.myUserHandle()) ?: emptyList()
    } catch (_: Throwable) { emptyList() }

    fun activeCount(pkg: String): Int = try {
        activeNotifications.count { it.packageName == pkg }
    } catch (_: Throwable) { -1 }
}
