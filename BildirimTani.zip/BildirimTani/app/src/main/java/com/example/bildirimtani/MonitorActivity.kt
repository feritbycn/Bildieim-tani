package com.example.bildirimtani

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MonitorActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var out: TextView
    private lateinit var etExpected: EditText

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        title = "Uygulama bildirimi analizi"
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }
        fun btn(t: String, a: () -> Unit) {
            root.addView(Button(this).apply { text = t; isAllCaps = false; setOnClickListener { a() } })
        }
        root.addView(TextView(this).apply {
            textSize = 13f
            text = "NASIL KULLANILIR\n" +
                "1) Bildirim erişimini aç (bu uygulamaya izin ver).\n" +
                "2) İzlenecek uygulamayı seç (ör. ezan vakti uygulaması).\n" +
                "3) İsteğe bağlı: aşağıya beklenen vakitleri yaz (gerçek gecikmeyi ölçer).\n" +
                "4) İsteğe bağlı: Kullanım erişimini aç ('uygulamayı açınca tekrar geliyor' tespiti için).\n" +
                "5) Bir vakit bildirimi gelsin. Sonra bildirimi silin, uygulamayı bir kez açıp çıkın.\n" +
                "6) 'Analiz raporu oluştur'a bas."
        })
        status = TextView(this).apply { textSize = 13f; setPadding(0, 16, 0, 16); typeface = Typeface.MONOSPACE }
        root.addView(status)

        btn("🔓 1) Bildirim erişimini aç") { openListenerSettings() }
        btn("⚙️ Bu uygulamanın ayarları (kısıtlı ayar izni için)") { openAppSettings() }
        btn("📱 2) İzlenecek uygulamayı seç") { pickApp() }
        etExpected = EditText(this).apply {
            hint = "3) Beklenen vakitler: 05:42, 13:10, 16:25"
            inputType = InputType.TYPE_CLASS_TEXT
            setText(NotifStore.prefs(this@MonitorActivity).getString("expected", ""))
        }
        root.addView(etExpected)
        btn("📊 4) Kullanım erişimini aç (isteğe bağlı)") {
            try { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
            catch (_: Exception) { openAppSettings() }
        }
        btn("📄 Analiz raporu oluştur") { analyze() }
        btn("📋 Raporu kopyala") {
            getSystemService(ClipboardManager::class.java)
                .setPrimaryClip(ClipData.newPlainText("analiz", out.text.toString()))
            Toast.makeText(this, "Kopyalandı", Toast.LENGTH_SHORT).show()
        }
        btn("📤 Raporu paylaş") {
            startActivity(Intent.createChooser(
                Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, out.text.toString()),
                "Raporu paylaş"))
        }
        btn("🗑 Kayıtları sil") { NotifStore.clear(this); refreshStatus(); out.text = "" }

        out = TextView(this).apply {
            setTextIsSelectable(true); typeface = Typeface.MONOSPACE; textSize = 12f
            setPadding(0, 24, 0, 0)
        }
        root.addView(out)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); refreshStatus() }
    override fun onPause() { super.onPause(); saveExpected() }

    private fun saveExpected() {
        NotifStore.prefs(this).edit().putString("expected", etExpected.text.toString()).apply()
    }

    private fun refreshStatus() {
        val ev = NotifStore.readAll(this)
        val pkg = NotifStore.targetPkg(this)
        val p = ev.count { it.optString("t") == "P" && it.optString("pkg") == pkg }
        val r = ev.count { it.optString("t") == "R" && it.optString("pkg") == pkg }
        val on = NotifStore.listenerEnabled(this)
        status.text = buildString {
            appendLine("Bildirim erişimi : ${if (on) "AÇIK ✔" else "KAPALI ✘"}")
            appendLine("İzlenen uygulama : ${NotifStore.targetLabel(this@MonitorActivity) ?: "— seçilmedi —"}")
            appendLine("Kayıt            : $p gelen, $r silinen")
            append("Kullanım erişimi : ${if (NotifStore.usageAllowed(this@MonitorActivity)) "AÇIK ✔" else "kapalı (isteğe bağlı)"}")
            if (!on) append("\n\nİzin ekranında bu uygulama tıklanamıyorsa: 'Bu uygulamanın ayarları' → sağ üst ⋮ → 'Kısıtlanmış ayarlara izin ver', sonra tekrar deneyin.")
        }
    }

    private fun openListenerSettings() {
        try { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        catch (_: Exception) { openAppSettings() }
    }

    private fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            .setData(Uri.parse("package:$packageName")))
    }

    private fun select(pkg: String, label: String) {
        val old = NotifStore.targetPkg(this)
        if (old != null && old != pkg) NotifStore.clear(this)
        NotifStore.prefs(this).edit().putString("pkg", pkg).putString("label", label).apply()
        refreshStatus()
        Toast.makeText(this, "$label izleniyor", Toast.LENGTH_SHORT).show()
    }

    private fun pickApp() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val apps = pm.queryIntentActivities(intent, 0)
            .map { Pair(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.second != packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
        var shown = apps
        val names = mutableListOf<String>()
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, names)
        fun fill(q: String) {
            shown = apps.filter { q.isBlank() || it.first.contains(q, true) || it.second.contains(q, true) }
            names.clear(); names.addAll(shown.map { "${it.first}\n${it.second}" })
            adapter.notifyDataSetChanged()
        }
        fill("")
        val et = EditText(this).apply { hint = "Ara (örn: ezan, vakit)" }
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { fill(s?.toString() ?: "") }
            override fun afterTextChanged(s: Editable?) {}
        })
        val lv = ListView(this).apply { this.adapter = adapter }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(24, 16, 24, 0)
            addView(et)
            addView(lv, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (resources.displayMetrics.heightPixels * 0.5).toInt()))
        }
        var dlg: AlertDialog? = null
        lv.setOnItemClickListener { _, _, pos, _ ->
            shown.getOrNull(pos)?.let { select(it.second, it.first) }
            dlg?.dismiss()
        }
        val d = AlertDialog.Builder(this).setTitle("İzlenecek uygulama").setView(box)
            .setNegativeButton("İptal", null).create()
        dlg = d
        d.show()
    }

    private fun analyze() {
        saveExpected()
        val pkg = NotifStore.targetPkg(this)
        if (pkg == null) { Toast.makeText(this, "Önce uygulama seç", Toast.LENGTH_LONG).show(); return }
        if (!NotifStore.listenerEnabled(this)) {
            Toast.makeText(this, "Önce bildirim erişimini aç", Toast.LENGTH_LONG).show()
        }
        out.text = try {
            Analyzer.run(this, pkg, NotifStore.targetLabel(this) ?: pkg, etExpected.text.toString())
        } catch (t: Throwable) {
            "RAPOR OLUŞTURULAMADI:\n" + android.util.Log.getStackTraceString(t)
        }
    }
}
