package com.example.bildirimtani

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

const val CHANNEL_ID = "tani_test"

fun ensureChannel(c: Context) {
    val nm = c.getSystemService(NotificationManager::class.java)
    if (nm.getNotificationChannel(CHANNEL_ID) == null) {
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Test bildirimleri", NotificationManager.IMPORTANCE_HIGH)
        )
    }
}

fun fmt(t: Long): String =
    SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(t))

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val planned = i.getLongExtra("planned", 0L)
        val now = System.currentTimeMillis()
        val delay = (now - planned) / 1000
        val sp = c.getSharedPreferences("log", Context.MODE_PRIVATE)
        val old = sp.getString("tests", "") ?: ""
        val line = "Planlanan ${fmt(planned)} | Gerçekleşen ${fmt(now)} | Gecikme: $delay sn"
        sp.edit().putString("tests", line + "\n" + old).apply()

        try {
            ensureChannel(c)
            val n = Notification.Builder(c, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Test bildirimi")
                .setContentText("Gecikme: $delay sn")
                .setAutoCancel(true)
                .build()
            c.getSystemService(NotificationManager::class.java).notify(1001, n)
        } catch (e: Exception) {
            sp.edit().putString("tests", "Bildirim gösterilemedi: ${e.message}\n" + line + "\n" + old).apply()
        }
    }
}
