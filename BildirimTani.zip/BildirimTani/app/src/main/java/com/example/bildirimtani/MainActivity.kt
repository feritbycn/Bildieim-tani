package com.example.bildirimtani

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.NotificationManager
import android.app.usage.UsageStatsManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var tv: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                getSharedPreferences("log", MODE_PRIVATE).edit()
                    .putString("crash", android.util.Log.getStackTraceString(e)).commit()
            } catch (_: Throwable) {}
            prev?.uncaughtException(t, e)
        }
        try { ensureChannel(this) } catch (_: Throwable) {}
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }
        fun btn(t: String, a: () -> Unit) {
            root.addView(Button(this).apply {
                text = t; isAllCaps = false; setOnClickListener { a() }
            })
        }
        btn("📋 Raporu KOPYALA") { copyReport() }
        btn("📤 Raporu paylaş") { shareReport() }
        btn("🔄 Raporu yenile") { refresh() }
        btn("🔔 Bildirim iznini iste") { askNotifPermission() }
        btn("🔋 Pil optimizasyonunu kapat") { openBattery() }
        btn("⏰ Kesin alarm iznini aç") { openExactAlarm() }
        btn("⚙️ Uygulama ayarları (otomatik başlatma vb.)") { openAppSettings() }
        btn("🧪 1 dk sonra test bildirimi") { scheduleTest(1) }
        btn("🧪 5 dk test (ekranı kapat, bekle)") { scheduleTest(5) }
        btn("🗑 Test kayıtlarını sil") {
            getSharedPreferences("log", MODE_PRIVATE).edit().clear().apply(); refresh()
        }
        tv = TextView(this).apply {
            setTextIsSelectable(true); typeface = Typeface.MONOSPACE; textSize = 12f
            setPadding(0, 24, 0, 0)
        }
        root.addView(tv)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        tv.text = try { report() } catch (t: Throwable) {
            "RAPOR OLUŞTURULAMADI:\n" + android.util.Log.getStackTraceString(t)
        }
    }

    private fun copyReport() {
        val cm = getSystemService(ClipboardManager::class.java)
        cm.setPrimaryClip(ClipData.newPlainText("rapor", report()))
        Toast.makeText(this, "Rapor kopyalandı", Toast.LENGTH_SHORT).show()
    }

    private fun shareReport() {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, report())
        }
        startActivity(Intent.createChooser(i, "Raporu paylaş"))
    }

    private fun askNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        } else {
            startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        }
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(rc, p, r); refresh()
    }

    private fun openBattery() {
        try {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                .setData(Uri.parse("package:$packageName")))
        } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
            catch (e2: Exception) { openAppSettings() }
        }
    }

    private fun openExactAlarm() {
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                    .setData(Uri.parse("package:$packageName")))
            } catch (e: Exception) { openAppSettings() }
        } else Toast.makeText(this, "Bu Android sürümünde gerekmiyor", Toast.LENGTH_SHORT).show()
    }

    private fun openAppSettings() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            .setData(Uri.parse("package:$packageName")))
    }

    private fun scheduleTest(min: Int) {
        val am = getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            Toast.makeText(this, "Önce 'Kesin alarm iznini aç'a bas", Toast.LENGTH_LONG).show(); return
        }
        val t = System.currentTimeMillis() + min * 60_000L
        val pi = PendingIntent.getBroadcast(
            this, min, Intent(this, AlarmReceiver::class.java).putExtra("planned", t),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
        Toast.makeText(this, "Test ${fmt(t)} için kuruldu. Uygulamayı kapatıp ekranı kilitle.", Toast.LENGTH_LONG).show()
    }

    private fun yn(b: Boolean) = if (b) "EVET" else "HAYIR"

    private fun report(): String {
        val problems = mutableListOf<String>()
        val d = StringBuilder()
        fun line(label: String, f: () -> String) {
            try { d.appendLine("$label: ${f()}") }
            catch (t: Throwable) { d.appendLine("$label: OKUNAMADI (${t.javaClass.simpleName}: ${t.message})") }
        }

        line("Marka/Model") { "${Build.MANUFACTURER} ${Build.MODEL}" }
        line("Android") { "${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})" }
        line("Arayüz/ROM") { Build.DISPLAY }

        line("Bildirimler açık") {
            val on = getSystemService(NotificationManager::class.java).areNotificationsEnabled()
            if (!on) problems.add("Bildirimler bu uygulama için kapalı.")
            yn(on)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            line("Bildirim izni (Android 13+)") {
                val ok = checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
                if (!ok) problems.add("Bildirim izni verilmemiş.")
                yn(ok)
            }
        }
        line("Kanal önem düzeyi (4=yüksek,3=varsayılan,2=düşük,0=kapalı)") {
            val ch = getSystemService(NotificationManager::class.java).getNotificationChannel(CHANNEL_ID)
            if (ch != null && ch.importance < 3) problems.add("Bildirim kanalı düşük öncelikte, ses/pop-up gecikebilir.")
            "${ch?.importance}"
        }
        line("Pil optimizasyonundan muaf") {
            val ign = getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)
            if (!ign) problems.add("Pil optimizasyonu AÇIK: sistem arka planda uygulamayı uyutup alarm/bildirimi geciktirebilir.")
            yn(ign)
        }
        if (Build.VERSION.SDK_INT >= 31) {
            line("Kesin alarm izni") {
                val ex = getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
                if (!ex) problems.add("Kesin alarm izni yok: vakit bildirimleri dakikalarca geç gelebilir.")
                yn(ex)
            }
        }
        line("Arka plan kısıtlı") {
            val br = getSystemService(ActivityManager::class.java).isBackgroundRestricted
            if (br) problems.add("Arka plan kullanımı KISITLANMIŞ.")
            yn(br)
        }
        line("Bekleme kovası (standby bucket)") {
            val bucket = getSystemService(UsageStatsManager::class.java).appStandbyBucket
            val name = when (bucket) {
                10 -> "ACTIVE"; 20 -> "WORKING_SET"; 30 -> "FREQUENT"
                40 -> "RARE"; 45 -> "RESTRICTED"; else -> "?"
            }
            if (bucket >= 40) problems.add("Uygulama '$name' kovasında: alarm ve işler ciddi şekilde ertelenir.")
            "$name ($bucket)"
        }
        line("Veri tasarrufu") {
            val s = getSystemService(ConnectivityManager::class.java).restrictBackgroundStatus
            if (s == ConnectivityManager.RESTRICT_BACKGROUND_STATUS_ENABLED)
                problems.add("Veri tasarrufu açık ve uygulama muaf değil.")
            when (s) {
                ConnectivityManager.RESTRICT_BACKGROUND_STATUS_DISABLED -> "Kapalı"
                ConnectivityManager.RESTRICT_BACKGROUND_STATUS_WHITELISTED -> "Açık ama uygulama muaf"
                else -> "AÇIK (uygulama muaf değil)"
            }
        }
        line("Pil tasarrufu modu") {
            val ps = getSystemService(PowerManager::class.java).isPowerSaveMode
            if (ps) problems.add("Pil tasarrufu modu açık.")
            yn(ps)
        }
        line("Doze (derin uyku) şu an") { yn(getSystemService(PowerManager::class.java).isDeviceIdleMode) }
        line("Otomatik saat / saat dilimi") {
            val a = Settings.Global.getInt(contentResolver, Settings.Global.AUTO_TIME, 0) == 1
            val z = Settings.Global.getInt(contentResolver, Settings.Global.AUTO_TIME_ZONE, 0) == 1
            if (!a || !z) problems.add("Otomatik saat/saat dilimi kapalı: vakitler yanlış hesaplanabilir.")
            "${yn(a)} / ${yn(z)}"
        }
        line("Saat dilimi") { java.util.TimeZone.getDefault().id }

        val sp = getSharedPreferences("log", MODE_PRIVATE)
        val sb = StringBuilder()
        sb.appendLine("=== BİLDİRİM TANI RAPORU ===")
        sb.appendLine("Tarih: ${java.util.Date()}")
        sb.appendLine()
        val crash = sp.getString("crash", null)
        if (crash != null) {
            sb.appendLine("--- ÖNCEKİ ÇÖKME KAYDI ---")
            sb.appendLine(crash.take(1500))
            sb.appendLine()
        }
        sb.appendLine("--- TESPİT EDİLEN SORUNLAR ---")
        if (problems.isEmpty()) sb.appendLine("Ayarlarda belirgin sorun yok (üretici kısıtlaması olabilir, aşağıya bak).")
        else problems.forEach { sb.appendLine("• $it") }
        sb.appendLine()
        sb.appendLine("--- DETAYLAR ---")
        sb.append(d)
        sb.appendLine()
        sb.appendLine("--- ÜRETİCİYE ÖZEL NOT ---")
        sb.appendLine(try { oemTip() } catch (t: Throwable) { "-" })
        sb.appendLine()
        sb.appendLine("--- ALARM TESTLERİ (en yeni üstte) ---")
        val log = sp.getString("tests", "") ?: ""
        sb.appendLine(if (log.isBlank()) "Henüz test yapılmadı." else log.trim())
        return sb.toString()
    }

    private fun oemTip(): String {
        val m = Build.MANUFACTURER.lowercase()
        return when {
            "xiaomi" in m || "redmi" in m || "poco" in m ->
                "Xiaomi/MIUI/HyperOS: 'Otomatik başlatma' aç, Pil tasarrufu > 'Kısıtlama yok', son uygulamalarda uygulamayı kilitle. Bildirimlerde 'Kilit ekranı' ve 'Yüzen' izinlerini aç."
            "huawei" in m || "honor" in m ->
                "Huawei/Honor: Uygulama başlatma > Elle yönet (3 seçeneği de aç). Pil > Uygulama başlatma. Güç yoğun uygulama uyarısını kapat."
            "oppo" in m || "realme" in m || "oneplus" in m ->
                "OPPO/Realme/OnePlus: Otomatik başlatma + Arka planda çalışma izni ver, Pil > 'Arka plan etkinliğine izin ver', uygulamayı son uygulamalarda kilitle."
            "vivo" in m || "iqoo" in m ->
                "Vivo/iQOO: i Yönetici > Arka plan güç tüketimi > 'Kısıtlama yok'; Otomatik başlatma aç."
            "samsung" in m ->
                "Samsung: Pil > Arka plan kullanım sınırları > 'Uyuyan uygulamalar' ve 'Derin uyku' listesinden uygulamayı çıkar; 'Kullanılmayan uygulamaları uyut' kapat."
            "asus" in m || "tecno" in m || "infinix" in m || "itel" in m ->
                "${Build.MANUFACTURER}: Otomatik başlatma / Arka plan yöneticisi / Pil optimizasyonu ayarlarında uygulamaya izin ver."
            else -> "Bu üretici için özel not yok. Pil ve otomatik başlatma ayarlarına bak."
        }
    }
}
