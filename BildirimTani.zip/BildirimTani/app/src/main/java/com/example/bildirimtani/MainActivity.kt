package com.example.bildirimtani

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.NotificationManager
import android.app.usage.UsageStatsManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.provider.Settings.Secure
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var tv: TextView
    private lateinit var appSpinner: Spinner
    private var apps: List<AppChoice> = emptyList()
    data class AppChoice(val label: String, val pkg: String) { override fun toString() = "$label ($pkg)" }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try { getSharedPreferences("log", MODE_PRIVATE).edit().putString("crash", android.util.Log.getStackTraceString(e)).commit() } catch (_: Throwable) {}
            prev?.uncaughtException(t, e)
        }
        try { ensureChannel(this) } catch (_: Throwable) {}
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 24, 32, 32) }
        fun btn(t: String, a: () -> Unit) { root.addView(Button(this).apply { text = t; isAllCaps = false; setOnClickListener { a() } }) }
        root.addView(TextView(this).apply { text = "BİLDİRİM TANI • UYGULAMA İZLEME"; textSize = 20f; setTypeface(null, Typeface.BOLD) })
        root.addView(TextView(this).apply { text = "Bir uygulama seç, bildirim erişimine izin ver ve gerçek bildirimlerin gösterilme/kaldırılma kayıtlarını incele. İzleme yalnızca seçtiğin uygulama için yerel olarak kaydedilir."; textSize = 14f; setPadding(0, 12, 0, 12) })
        appSpinner = Spinner(this)
        root.addView(appSpinner)
        btn("📱 Yüklü uygulamaları listele") { loadApps() }
        btn("🎯 Seçili uygulamayı izlemeye al") { selectApp() }
        btn("🔐 Bildirim erişimi ayarlarını aç") { openNotificationAccess() }
        btn("🕒 Kullanım erişimi ayarlarını aç (isteğe bağlı)") { openUsageAccess() }
        btn("📊 Bildirim olaylarını göster") { showEvents() }
        btn("📋 Tanı raporunu kopyala") { copyReport() }
        btn("📤 Tanı raporunu paylaş") { shareReport() }
        btn("🔄 Sistem raporunu yenile") { refresh() }
        btn("🔔 Bu uygulamanın bildirim iznini iste") { askNotifPermission() }
        btn("🔋 Pil optimizasyonu ayarları") { openBattery() }
        btn("⏰ Kesin alarm izni ayarları") { openExactAlarm() }
        btn("⚙️ Bu uygulamanın ayarları") { openAppSettings() }
        btn("🧪 1 dk sonra test bildirimi") { scheduleTest(1) }
        btn("🧪 5 dk test (ekranı kapat, bekle)") { scheduleTest(5) }
        btn("🗑 İzleme kayıtlarını temizle") {
            getSharedPreferences("log", MODE_PRIVATE).edit().remove(NotificationMonitor.KEY_EVENTS).remove("last_sig").remove("last_sig_at").apply(); showEvents()
        }
        tv = TextView(this).apply { setTextIsSelectable(true); typeface = Typeface.MONOSPACE; textSize = 12f; setPadding(0, 24, 0, 0) }
        root.addView(tv)
        setContentView(ScrollView(this).apply { addView(root) })
        loadApps()
    }

    override fun onResume() { super.onResume(); if (::tv.isInitialized) refresh() }

    private fun loadApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(intent, 0).mapNotNull {
            val pkg = it.activityInfo?.packageName ?: return@mapNotNull null
            if (pkg == packageName) return@mapNotNull null
            val label = it.loadLabel(pm)?.toString() ?: pkg
            AppChoice(label, pkg)
        }.distinctBy { it.pkg }.sortedBy { it.label.lowercase() }
        appSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, apps)
        val selected = getSharedPreferences("log", MODE_PRIVATE).getString(NotificationMonitor.KEY_PACKAGE, null)
        val index = apps.indexOfFirst { it.pkg == selected }
        if (index >= 0) appSpinner.setSelection(index)
        Toast.makeText(this, "${apps.size} uygulama listelendi", Toast.LENGTH_SHORT).show()
    }

    private fun selectApp() {
        if (apps.isEmpty() || appSpinner.selectedItemPosition !in apps.indices) { loadApps(); return }
        val app = apps[appSpinner.selectedItemPosition]
        getSharedPreferences("log", MODE_PRIVATE).edit().putString(NotificationMonitor.KEY_PACKAGE, app.pkg).apply()
        Toast.makeText(this, "İzlenecek uygulama: ${app.label}. Şimdi Bildirim Erişimi iznini aç.", Toast.LENGTH_LONG).show()
        refresh()
    }

    private fun openNotificationAccess() {
        try { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }
    private fun openUsageAccess() {
        try { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
    }
    private fun isListenerEnabled(): Boolean {
        val enabled = Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return enabled.split(":").any { it.contains(packageName) }
    }

    private fun showEvents() {
        val sp = getSharedPreferences("log", MODE_PRIVATE)
        val pkg = sp.getString(NotificationMonitor.KEY_PACKAGE, null)
        val events = sp.getString(NotificationMonitor.KEY_EVENTS, "") ?: ""
        val lines = events.lines().filter { it.isNotBlank() }.mapNotNull { raw -> try { JSONObject(raw) } catch (_: Exception) { null } }
        val out = StringBuilder("=== BİLDİRİM OLAY İZLEYİCİSİ ===\n")
        out.appendLine("Seçili paket: ${pkg ?: "SEÇİLMEDİ"}")
        out.appendLine("Bildirim erişimi açık: ${if (isListenerEnabled()) "EVET" else "HAYIR — ayarlardan izin ver"}")
        out.appendLine("Kaydedilen olay: ${lines.size}")
        out.appendLine("Not: Aynı başlık/metin 2 dakika içinde tekrar gösterilirse olası tekrar olarak işaretlenir; bu kesin hata kanıtı değildir.\n")
        if (lines.isEmpty()) out.appendLine("Henüz olay yok. Uygulama seç, bildirim erişimini aç ve hedef uygulamada test et.")
        lines.forEach { e ->
            val dup = e.optBoolean("duplicateSuspected", false)
            out.appendLine("${NotificationMonitor.formatTime(e.optLong("at"))} | ${e.optString("event")} ${if (dup) "| OLASI TEKRAR" else ""}")
            out.appendLine("  ${e.optString("app")} (${e.optString("package")})")
            out.appendLine("  Başlık: ${e.optString("title")}")
            out.appendLine("  Metin: ${e.optString("body")}")
            out.appendLine("  Bildirim ID/etiket: ${e.optInt("id")} / ${e.optString("tag")}")
            if (e.optString("reason").isNotBlank()) out.appendLine("  Kaldırılma: ${e.optString("reason")}")
            out.appendLine()
        }
        tv.text = out.toString()
    }

    private fun refresh() {
        tv.text = try { report() } catch (t: Throwable) { "RAPOR OLUŞTURULAMADI:\n" + android.util.Log.getStackTraceString(t) }
    }
    private fun copyReport() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("rapor", if (tv.text.contains("BİLDİRİM OLAY İZLEYİCİSİ")) tv.text else report()))
        Toast.makeText(this, "Ekrandaki rapor kopyalandı", Toast.LENGTH_SHORT).show()
    }
    private fun shareReport() {
        val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, if (::tv.isInitialized && tv.text.contains("BİLDİRİM OLAY İZLEYİCİSİ")) tv.text else report()) }
        startActivity(Intent.createChooser(i, "Raporu paylaş"))
    }
    private fun askNotifPermission() {
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        else startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
    }
    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) { super.onRequestPermissionsResult(rc, p, r); refresh() }
    private fun openBattery() {
        try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).setData(Uri.parse("package:$packageName"))) }
        catch (_: Exception) { try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Exception) { openAppSettings() } }
    }
    private fun openExactAlarm() {
        if (Build.VERSION.SDK_INT >= 31) try { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).setData(Uri.parse("package:$packageName"))) } catch (_: Exception) { openAppSettings() }
        else Toast.makeText(this, "Bu Android sürümünde gerekmiyor", Toast.LENGTH_SHORT).show()
    }
    private fun openAppSettings() { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).setData(Uri.parse("package:$packageName"))) }
    private fun scheduleTest(min: Int) {
        val am = getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) { Toast.makeText(this, "Önce kesin alarm iznini aç", Toast.LENGTH_LONG).show(); return }
        val t = System.currentTimeMillis() + min * 60_000L
        val pi = PendingIntent.getBroadcast(this, min, Intent(this, AlarmReceiver::class.java).putExtra("planned", t), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
        Toast.makeText(this, "Test ${fmt(t)} için kuruldu. Ekranı kilitleyip bekleyebilirsin.", Toast.LENGTH_LONG).show()
    }
    private fun yn(b: Boolean) = if (b) "EVET" else "HAYIR"
    private fun report(): String {
        val problems = mutableListOf<String>(); val d = StringBuilder()
        fun line(label: String, f: () -> String) { try { d.appendLine("$label: ${f()}") } catch (t: Throwable) { d.appendLine("$label: OKUNAMADI (${t.javaClass.simpleName}: ${t.message})") } }
        line("Marka/Model") { "${Build.MANUFACTURER} ${Build.MODEL}" }; line("Android") { "${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})" }; line("Arayüz/ROM") { Build.DISPLAY }
        line("Bildirimler açık") { val on = getSystemService(NotificationManager::class.java).areNotificationsEnabled(); if (!on) problems.add("Bu uygulama için bildirimler kapalı."); yn(on) }
        if (Build.VERSION.SDK_INT >= 33) line("Bildirim izni (Android 13+)") { val ok = checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED; if (!ok) problems.add("Bildirim izni verilmemiş."); yn(ok) }
        line("Kanal önem düzeyi (4=yüksek,3=varsayılan,2=düşük,0=kapalı)") { val ch = getSystemService(NotificationManager::class.java).getNotificationChannel(CHANNEL_ID); if (ch != null && ch.importance < 3) problems.add("Test kanalı düşük öncelikte."); "${ch?.importance}" }
        line("Pil optimizasyonundan muaf") { val ign = getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName); if (!ign) problems.add("Pil optimizasyonu açık olabilir."); yn(ign) }
        if (Build.VERSION.SDK_INT >= 31) line("Kesin alarm izni") { val ex = getSystemService(AlarmManager::class.java).canScheduleExactAlarms(); if (!ex) problems.add("Kesin alarm izni yok."); yn(ex) }
        line("Arka plan kısıtlı") { val br = getSystemService(ActivityManager::class.java).isBackgroundRestricted; if (br) problems.add("Arka plan kullanımı kısıtlanmış."); yn(br) }
        line("Bekleme kovası") { val bucket = getSystemService(UsageStatsManager::class.java).appStandbyBucket; "${when(bucket){10->"ACTIVE";20->"WORKING_SET";30->"FREQUENT";40->"RARE";45->"RESTRICTED";else->"?"}} ($bucket)" }
        line("Veri tasarrufu") { val s = getSystemService(ConnectivityManager::class.java).restrictBackgroundStatus; when(s){ConnectivityManager.RESTRICT_BACKGROUND_STATUS_DISABLED->"Kapalı";ConnectivityManager.RESTRICT_BACKGROUND_STATUS_WHITELISTED->"Açık ama muaf";else->"Açık/muaf değil veya okunamadı"} }
        line("Pil tasarrufu modu") { yn(getSystemService(PowerManager::class.java).isPowerSaveMode) }; line("Doze") { yn(getSystemService(PowerManager::class.java).isDeviceIdleMode) }
        line("Otomatik saat / saat dilimi") { val a = Settings.Global.getInt(contentResolver, Settings.Global.AUTO_TIME, 0)==1; val z=Settings.Global.getInt(contentResolver,Settings.Global.AUTO_TIME_ZONE,0)==1; if(!a||!z)problems.add("Otomatik saat veya saat dilimi kapalı."); "${yn(a)} / ${yn(z)}" }
        line("Saat dilimi") { java.util.TimeZone.getDefault().id }
        val sp=getSharedPreferences("log",MODE_PRIVATE); val pkg=sp.getString(NotificationMonitor.KEY_PACKAGE,null)
        return buildString {
            appendLine("=== BİLDİRİM TANI RAPORU ==="); appendLine("Tarih: ${java.util.Date()}"); appendLine("İzlenen uygulama: ${pkg ?: "Seçilmedi"}"); appendLine("Bildirim erişimi: ${yn(isListenerEnabled())}"); appendLine("--- TESPİT EDİLEN SORUNLAR ---")
            if(problems.isEmpty()) appendLine("Temel sistem ayarlarında belirgin sorun yok.") else problems.forEach { appendLine("• $it") }
            appendLine("--- DETAYLAR ---"); append(d); appendLine(); appendLine("--- ALARM TESTLERİ ---"); appendLine(sp.getString("tests", "Henüz test yapılmadı.") ?: "Henüz test yapılmadı.")
            appendLine(); appendLine("--- HEDEF UYGULAMA OLAY SAYISI ---"); appendLine((sp.getString(NotificationMonitor.KEY_EVENTS,"") ?: "").lines().count { it.isNotBlank() }.toString())
            appendLine("Not: Bildirim erişimi, seçilen uygulamanın bildirim başlık/metnini okuyabilir. Kayıtlar cihazda tutulur; rapor paylaşılırsa içeriği sen paylaşmış olursun.")
        }
    }
}
