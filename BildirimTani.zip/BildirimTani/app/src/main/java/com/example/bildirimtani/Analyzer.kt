package com.example.bildirimtani

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.PowerManager
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/** Kaydedilen olaylardan çift bildirim ve gecikme tanısı üretir. */
object Analyzer {
    class Ev(
        val t: String, val pkg: String, val rx: Long, val post: Long, val whenMs: Long,
        val key: String, val id: Int, val tag: String, val ch: String, val flags: Int,
        val title: String, val text: String, val reason: Int, val msg: String
    )

    private fun parse(o: JSONObject) = Ev(
        o.optString("t"), o.optString("pkg"), o.optLong("rx"), o.optLong("post"), o.optLong("when"),
        o.optString("key"), o.optInt("id"), o.optString("tag"), o.optString("ch"), o.optInt("flags"),
        o.optString("title"), o.optString("text"), o.optInt("reason", -1), o.optString("msg")
    )

    private fun t(ms: Long) = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(ms))
    private fun dt(ms: Long) = SimpleDateFormat("dd.MM HH:mm:ss", Locale.getDefault()).format(Date(ms))

    private fun reasonName(r: Int) = when (r) {
        1 -> "bildirime dokunuldu"
        2 -> "SİZ sildiniz"
        3 -> "SİZ 'tümünü temizle' dediniz"
        4 -> "sistem hatası"
        5 -> "paket değişti"
        6 -> "kullanıcı durduruldu"
        7 -> "paket engellendi"
        8 -> "UYGULAMA kendisi iptal etti"
        9 -> "UYGULAMA tümünü iptal etti"
        10, 11 -> "dinleyici iptal etti"
        12 -> "grup özeti kalktı"
        13 -> "gruplama"
        14 -> "paket askıya alındı"
        17 -> "kanal engellendi"
        18 -> "ertelendi"
        19 -> "zaman aşımı"
        -1 -> "?"
        else -> "kod $r"
    }

    private fun sec(d: Double) = if (d < 10) String.format(Locale.US, "%.1f", d) else d.toLong().toString()

    private fun humanDelay(s: Long): String {
        val a = abs(s)
        val txt = if (a >= 120) "${a / 60} dk ${a % 60} sn" else "$a sn"
        return if (s < 0) "$txt ERKEN" else "$txt GEÇ"
    }

    private fun parseExpected(raw: String): List<Pair<Int, Int>> =
        Regex("(\\d{1,2})[:.](\\d{2})").findAll(raw).mapNotNull {
            val h = it.groupValues[1].toInt(); val m = it.groupValues[2].toInt()
            if (h in 0..23 && m in 0..59) Pair(h, m) else null
        }.toList()

    /** Bu bildirim anına en yakın (±90 dk) beklenen vakit; yoksa null. */
    private fun nearestExpected(postMs: Long, exp: List<Pair<Int, Int>>): Long? {
        var best: Long? = null
        for (off in -1..1) for ((h, m) in exp) {
            val cal = Calendar.getInstance().apply {
                timeInMillis = postMs; add(Calendar.DAY_OF_YEAR, off)
                set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m)
                set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val cand = cal.timeInMillis
            if (best == null || abs(cand - postMs) < abs(best - postMs)) best = cand
        }
        return best?.takeIf { abs(it - postMs) <= 90 * 60_000L }
    }

    private fun foregroundTimes(c: Context, pkg: String, from: Long, to: Long): List<Long> {
        if (!NotifStore.usageAllowed(c)) return emptyList()
        return try {
            val usm = c.getSystemService(UsageStatsManager::class.java)
            val ev = usm.queryEvents(from, to)
            val e = UsageEvents.Event()
            val out = mutableListOf<Long>()
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e)
                if (e.packageName == pkg && e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) out.add(e.timeStamp)
            }
            out
        } catch (_: Throwable) { emptyList() }
    }

    class Dup(val p: Ev, val prior: Ev, val kind: String, val text: String)

    fun run(c: Context, pkg: String, label: String, expectedRaw: String): String {
        val sb = StringBuilder()
        val now = System.currentTimeMillis()
        val all = NotifStore.readAll(c).map { parse(it) }
        val mine = all.filter { (it.t == "P" || it.t == "R") && it.pkg == pkg }
        val sys = all.filter { it.t == "S" }
        val posts = mine.filter { it.t == "P" && (it.flags and 512) == 0 } // 512 = grup özeti, hariç
        val removes = mine.filter { it.t == "R" }
        val causes = mutableListOf<String>()   // uygulamanın telefon tarafındaki olası sorunları

        sb.appendLine("=== UYGULAMA BİLDİRİM ANALİZİ ===")
        sb.appendLine("Uygulama: $label ($pkg)")
        sb.appendLine("Rapor zamanı: ${dt(now)}")
        sb.appendLine()

        // ---------- 1) Uygulamanın telefondaki durumu ----------
        sb.appendLine("--- UYGULAMANIN TELEFONDAKİ DURUMU ---")
        fun line(l: String, f: () -> String) {
            try { sb.appendLine("$l: ${f()}") }
            catch (e: Throwable) { sb.appendLine("$l: OKUNAMADI (${e.javaClass.simpleName})") }
        }
        val ai = try { c.packageManager.getApplicationInfo(pkg, 0) } catch (_: Throwable) { null }
        line("Sürüm") { c.packageManager.getPackageInfo(pkg, 0).versionName ?: "?" }
        line("Zorla durdurulmuş") {
            val st = ai != null && (ai.flags and 0x200000) != 0
            if (st) causes.add("Uygulama 'durdurulmuş' durumda: kullanıcı uygulamayı açana kadar alarmları ve bildirimleri çalışmaz; açınca birikenler birden gelir.")
            if (st) "EVET" else "HAYIR"
        }
        line("Pil optimizasyonundan muaf") {
            val ign = c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(pkg)
            if (!ign) causes.add("Uygulama pil optimizasyonundan muaf değil: sistem arka planda uyutup vakit bildirimini geciktirebilir.")
            if (ign) "EVET" else "HAYIR"
        }
        line("Kesin alarm izni (appop)") {
            if (ai == null) "?" else when (NotifStore.opMode(c, "android:schedule_exact_alarm", ai.uid, pkg)) {
                AppOpsManager.MODE_ALLOWED -> "İZİNLİ"
                AppOpsManager.MODE_DEFAULT -> "Varsayılan (uygulamanın manifestine bağlı, kesin değil)"
                else -> { causes.add("Kesin alarm izni reddedilmiş görünüyor: vakitler dakikalarca geç gelebilir."); "REDDEDİLMİŞ" }
            }
        }
        val svc = NotifWatcher.instance
        line("Bildirim kanalları") {
            if (svc == null) "okunamadı (dinleyici bağlı değil)"
            else {
                val chs = svc.channelsOf(pkg)
                if (chs.isEmpty()) "yok/okunamadı"
                else chs.joinToString("; ") { ch ->
                    if (ch.importance == 0) causes.add("'${ch.name}' kanalı KAPALI.")
                    else if (ch.importance < 3) causes.add("'${ch.name}' kanalı düşük öncelikli: ses/açılır bildirim gecikmeli veya sessiz olabilir.")
                    "${ch.name} [${ch.id}] önem=${ch.importance}"
                }
            }
        }
        line("Şu an bildirim çubuğunda bu uygulamadan") {
            val n = svc?.activeCount(pkg) ?: -1
            if (n < 0) "?" else "$n adet"
        }
        sb.appendLine()

        // ---------- 2) İzleme kapsamı ----------
        sb.appendLine("--- İZLEME KAPSAMI ---")
        if (posts.isEmpty() && removes.isEmpty()) {
            sb.appendLine("Henüz bu uygulamadan hiç bildirim kaydedilmedi.")
            sb.appendLine("Bildirim erişimi açık ve uygulama seçili olmalı. Sonraki vakti bekleyin, gelen bildirimi silin, uygulamayı bir kez açın, sonra raporu yeniden alın.")
            if (causes.isNotEmpty()) {
                sb.appendLine(); sb.appendLine("--- TELEFON TARAFINDA OLASI SORUNLAR ---")
                causes.forEach { sb.appendLine("• $it") }
            }
            return sb.toString()
        }
        val first = (mine.minOfOrNull { it.rx } ?: now)
        sb.appendLine("İlk kayıt: ${dt(first)}  |  Gelen: ${posts.size}  |  Silinen: ${removes.size}")
        val cuts = sys.filter { it.msg.contains("koptu") }
        if (cuts.isNotEmpty()) {
            sb.appendLine("⚠ İzleme kesintisi ${cuts.size} kez oldu (${cuts.takeLast(3).joinToString { t(it.rx) }}). O anlarda kaçan olaylar olabilir; Bildirim Tanı'ya da pil muafiyeti verin.")
        }
        val fg = foregroundTimes(c, pkg, first - 60_000L, now)
        sb.appendLine(
            if (NotifStore.usageAllowed(c)) "Uygulamanın açılış zamanları: izleniyor (${fg.size} açılış)"
            else "Uygulamanın açılış zamanları: izlenmiyor (Kullanım erişimi kapalı; 'açınca tekrar geliyor' tespiti yapılamaz)"
        )
        sb.appendLine()

        // ---------- 3) Zaman çizelgesi ----------
        sb.appendLine("--- ZAMAN ÇİZELGESİ (son 30 olay) ---")
        val tl = mutableListOf<Pair<Long, String>>()
        for (p in mine) {
            if (p.t == "P") {
                val g = if ((p.flags and 512) != 0) " [grup özeti]" else ""
                val ongoing = if ((p.flags and 2) != 0) " [sürekli]" else ""
                tl.add(p.rx to "＋ GELDİ  id=${p.id} kanal=${p.ch}$ongoing$g  \"${p.title}\" / \"${p.text.take(40)}\"")
            } else tl.add(p.rx to "－ SİLİNDİ id=${p.id}  (${reasonName(p.reason)})")
        }
        fg.forEach { tl.add(it to "▶ Uygulama öne geldi / açıldı") }
        sys.forEach { tl.add(it.rx to "• ${it.msg}") }
        tl.sortedBy { it.first }.takeLast(30).forEach { sb.appendLine("${t(it.first)}  ${it.second}") }
        sb.appendLine()

        // ---------- 4) Çift bildirim ----------
        val dups = mutableListOf<Dup>()
        val dupPosts = HashSet<Ev>()
        for ((i, p) in posts.withIndex()) {
            if ((p.title + p.text).isBlank()) continue
            val prior = posts.take(i).lastOrNull { q ->
                p.rx - q.rx <= 10 * 60_000L && q.title == p.title &&
                    (q.text == p.text || (q.key != p.key && p.rx - q.rx <= 120_000L))
            } ?: continue
            val gap = (p.rx - prior.rx) / 1000.0
            val rem = removes.lastOrNull { it.key == p.key && it.rx >= prior.rx && it.rx <= p.rx }
            val opened = fg.any { it >= p.rx - 8000 && it <= p.rx + 1500 }
            val openTxt = if (opened) "  ← uygulama açıldığı sırada gönderildi" else ""
            val kind: String
            val txt: String
            if (p.key == prior.key && rem == null) {
                kind = "UPD"
                val once = if ((p.flags and 8) != 0) "" else " (setOnlyAlertOnce yok → her seferinde ses/titreşim verebilir)"
                txt = "${t(prior.rx)} geldi → ${t(p.rx)} AYNI bildirim silinmeden yeniden yayınlandı (${sec(gap)} sn sonra)$once$openTxt"
            } else if (p.key == prior.key && rem != null && rem.reason in 2..3) {
                kind = "USERDEL"
                txt = "${t(prior.rx)} geldi → ${t(rem.rx)} ${reasonName(rem.reason)} → ${t(p.rx)} AYNISI GERİ GELDİ (silmeden ${sec((p.rx - rem.rx) / 1000.0)} sn sonra)$openTxt"
            } else if (p.key == prior.key && rem != null && rem.reason in 8..9) {
                kind = "APPCANCEL"
                txt = "${t(prior.rx)} geldi → ${t(rem.rx)} uygulama kendisi kaldırdı → ${t(p.rx)} yeniden yayınladı (${sec((p.rx - rem.rx) / 1000.0)} sn sonra)$openTxt"
            } else if (p.key == prior.key) {
                kind = "OTHERDEL"
                txt = "${t(prior.rx)} geldi → ${t(rem!!.rx)} kaldırıldı (${reasonName(rem.reason)}) → ${t(p.rx)} yeniden geldi$openTxt"
            } else {
                kind = "DIFFID"
                val chTxt = if (p.ch != prior.ch) "FARKLI kanal (${prior.ch} / ${p.ch})" else "aynı kanal (${p.ch})"
                txt = "${t(prior.rx)} id=${prior.id} + ${t(p.rx)} id=${p.id} → aynı içerik iki ayrı bildirim olarak geldi (${sec(gap)} sn arayla, $chTxt)$openTxt"
            }
            dups.add(Dup(p, prior, kind, txt)); dupPosts.add(p)
        }
        sb.appendLine("--- ÇİFT BİLDİRİM TESPİTİ ---")
        if (dups.isEmpty()) sb.appendLine("Kayıtlı sürede aynı bildirimin tekrarı görülmedi.")
        else {
            sb.appendLine("${dups.size} tekrar bulundu:")
            dups.takeLast(15).forEachIndexed { i, d -> sb.appendLine("${i + 1}) ${d.text}") }
        }
        sb.appendLine()

        // ---------- 5) Gecikme ----------
        sb.appendLine("--- GECİKME ÖLÇÜMÜ ---")
        val exp = parseExpected(expectedRaw)
        val firsts = posts.filter { it !in dupPosts }
        var lateCount = 0; var maxLate = 0L; var openedLate = 0
        if (exp.isEmpty()) sb.appendLine("İpucu: 'Beklenen vakitler' kutusuna ezan saatlerini yazarsanız gerçek gecikme ölçülür (örn: 05:42, 13:10).")
        for (p in firsts.takeLast(20)) {
            val parts = mutableListOf<String>()
            val e = if (exp.isNotEmpty()) nearestExpected(p.post, exp) else null
            if (e != null) {
                val d = (p.post - e) / 1000
                parts.add("beklenen ${t(e)} → ${humanDelay(d)}")
                if (d > 60) {
                    lateCount++; if (d > maxLate) maxLate = d
                    if (fg.any { it >= p.rx - 8000 && it <= p.rx + 1500 }) openedLate++
                }
            }
            val w = p.post - p.whenMs
            if (p.whenMs > 0 && abs(w) in 2000..6 * 3600_000L)
                parts.add("uygulamanın yazdığı bildirim zamanı ${t(p.whenMs)} ↔ sisteme veriliş ${t(p.post)} (${humanDelay(w / 1000)})")
            val lat = (p.rx - p.post) / 1000
            if (lat > 5) parts.add("dinleyici ${lat} sn geç haberdar oldu (ölçüm bu kadar belirsiz)")
            sb.appendLine("${t(p.post)} \"${p.title.take(30)}\": " + (if (parts.isEmpty()) "ölçülecek referans yok (gecikme belirtisi yok)" else parts.joinToString(" | ")))
        }
        sb.appendLine()

        // ---------- 6) Yorum ----------
        sb.appendLine("--- SONUÇ / OLASI NEDENLER ---")
        val cnt = dups.groupingBy { it.kind }.eachCount()
        val dupOpened = dups.count { d -> fg.any { it >= d.p.rx - 8000 && it <= d.p.rx + 1500 } }
        var any = false
        fun say(s: String) { sb.appendLine("• $s"); any = true }
        (cnt["USERDEL"] ?: 0).let { if (it > 0) say("Siz bildirimi silince aynısı $it kez geri geldi. Bu telefon ayarı değil UYGULAMA davranışıdır: uygulama silinme olayına tepki verip bildirimi yeniden yayınlıyor ya da bir arka plan servisi bildirimi yeniden kuruyor. Uygulamanın kendi ayarlarında 'sürekli/kalıcı bildirim' veya 'vakit bildirimi' seçeneklerini kontrol edin; çözülmezse uygulama geliştiricisine bu raporu gönderin.") }
        (cnt["APPCANCEL"] ?: 0).let { if (it > 0) say("Uygulama bildirimi kendisi kaldırıp yeniden yayınladı ($it kez). Bu, bildirimi 'tazeleyen' bir kod (iptal et + yeniden gönder) olduğunu gösterir; her seferinde yeniden ses/titreşim verir. Uygulama hatasıdır.") }
        (cnt["UPD"] ?: 0).let { if (it > 0) say("Aynı bildirim silinmeden $it kez yeniden yayınlandı. Uygulama bildirimi her tetiklemede yeniden gönderiyor. Bu uygulama içi mantıktır; uygulama güncellemesi gerekir.") }
        (cnt["DIFFID"] ?: 0).let { if (it > 0) say("Aynı içerik iki FARKLI bildirim kimliğiyle $it kez geldi. En olası sebep: aynı vakit iki yoldan planlanmış (ör. hem yerel alarm hem sunucu/push, ya da alarm iki kez kurulmuş). Uygulamada 'bulut/push bildirimi' ve 'yerel bildirim' diye iki seçenek varsa birini kapatın; uygulamanın verisini temizleyip vakitleri yeniden kurmak da işe yarayabilir.") }
        if (dupOpened > 0) say("$dupOpened tekrar uygulama açıldığı anda geldi. Uygulama açılışta o günün bildirimlerini yeniden planlıyor/gösteriyor olabilir (geçmiş vakti 'hemen göster' hatası tipik bir nedendir).")
        if (openedLate > 0) say("$openedLate geç bildirim, siz uygulamayı açtığınız anda geldi. Yani arka planda alarm tetiklenmemiş, uygulama açılınca tetiklenmiş: sistem uygulamayı uyutmuş veya alarmları kısıtlamış demektir. Aşağıdaki telefon ayarlarına bakın.")
        if (lateCount > 0) say("$lateCount bildirim 1 dakikadan fazla geç geldi (en fazla ${humanDelay(maxLate)}).")
        if (!any) say("Kayıtlı sürede çift bildirim veya anlamlı gecikme görülmedi. Sorun ara sıra oluyorsa izlemeyi açık bırakıp birkaç vakit boyunca bekleyin, sorun olunca raporu alın.")
        if (causes.isNotEmpty()) {
            sb.appendLine()
            sb.appendLine("Telefon tarafında gecikmeye yol açabilecek ayarlar:")
            causes.forEach { sb.appendLine("  - $it") }
            sb.appendLine("  (Üretici notu için ana ekrandaki rapora bakın: otomatik başlatma / arka plan yöneticisi.)")
        }
        sb.appendLine()
        sb.appendLine("Not: Bu araç yalnızca uygulamanın sisteme ne zaman ne gönderdiğini görür; uygulamanın içindeki kodu göremez. 'Neden' kısmı kayıtlardan çıkarılan olasılıktır.")
        return sb.toString()
    }
}
